#ifndef QRK_TICKS_H
#define QRK_TICKS_H

/*!
  \file
  \brief �^�C���X�^���v�̎擾

  \author Satofumi KAMIMURA

  $Id$
*/


namespace qrk
{
    long ticks(void);
}

#endif /* !QRK_TICKS_H */
